# todomvc-common

> Bower component for some common utilities we use in every app


## License

MIT
